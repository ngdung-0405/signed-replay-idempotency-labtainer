#!/bin/bash
sudo cp /home/ubuntu/race_replay.py /usr/local/bin/race_replay
sudo chmod +x /usr/local/bin/race_replay /home/ubuntu/race_replay.py
