#!/bin/bash
set -e
./capture_request.sh
./replay_capture.sh
