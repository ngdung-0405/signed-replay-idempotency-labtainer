#!/bin/bash
set -e
source ~/captured_request.env

send_copy() {
  curl -sS -i --connect-timeout 5 --max-time 10 \
    -X POST http://192.168.10.2:8080/api/lab-transfer \
    -H 'Content-Type: application/json' \
    -H "X-Lab-Key-Id: $CLIENT" \
    -H "X-Lab-Nonce: $NONCE" \
    -H "Idempotency-Key: $IDEM" \
    -H "X-Lab-Signature: $SIGNATURE" \
    --data "$BODY"
}

send_copy > /tmp/replay-copy-1.out &
PID1=$!

send_copy > /tmp/replay-copy-2.out &
PID2=$!

wait "$PID1"
wait "$PID2"

echo "=== RESPONSE COPY 1 ==="
cat /tmp/replay-copy-1.out

echo "=== RESPONSE COPY 2 ==="
cat /tmp/replay-copy-2.out

STATUS_201=$(grep -h -c '201 Created' \
  /tmp/replay-copy-1.out /tmp/replay-copy-2.out || true)

STATUS_409=$(grep -h -c '409 Conflict' \
  /tmp/replay-copy-1.out /tmp/replay-copy-2.out || true)

echo "attacker_started=yes"
echo "replay_sent=yes"

if [ "$STATUS_201" -eq 1 ] && [ "$STATUS_409" -eq 1 ]; then
    echo "secure_replay_rejected=yes"
else
    echo "secure_replay_rejected=no"
fi
