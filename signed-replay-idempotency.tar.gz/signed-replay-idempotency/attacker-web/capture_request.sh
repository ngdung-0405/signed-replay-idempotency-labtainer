#!/bin/bash
set -e

read -rp "Nhập nhãn request capture (vd race-001): " LABEL

case "$LABEL" in
  ''|*[![:alnum:]_-]*)
    echo "Nhãn chỉ gồm chữ, số, - và _."
    exit 1
    ;;
esac

curl -sS \
  "http://192.168.10.2:8080/api/lab-capture?label=$LABEL" \
  > ~/captured_request.b64

base64 -d ~/captured_request.b64 > ~/captured_request.env

echo "=== Bản ghi đã capture và decode ==="
cat ~/captured_request.env

source ~/captured_request.env

printf '%s' "$NONCE" | sha256sum | awk '{print "nonce_fingerprint=" substr($1,1,12)}'

echo "capture_downloaded=yes"
