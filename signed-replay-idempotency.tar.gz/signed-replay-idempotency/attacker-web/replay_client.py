#!/usr/bin/env python3
import hashlib
import hmac
import http.client
import json
import threading

HOST="192.168.10.2"
PORT=8080
SECRET=b"LAB_ONLY_DEMO_HMAC_SECRET"

print("=== LAB REPLAYER: HAI REQUEST GIẢ LẬP ĐỒNG THỜI ===")
nonce=input("Nhập nonce (vd nonce-lab-race-001): ").strip()
idem=input("Nhập Idempotency-Key (vd transfer-lab-race-001): ").strip()

if not nonce or not idem or len(nonce)>80 or len(idem)>80:
    raise SystemExit("Nonce hoặc Idempotency-Key không hợp lệ.")

secure="secure" in nonce.lower() or "secure" in idem.lower()
note="SECURE_REPLAY_LAB" if secure else "RACE_REPLAY_LAB"

client="student-a"
body=json.dumps(
    {"from":client,"to":"lab-store","points":10,"note":note},
    separators=(",",":")
)
signature=hmac.new(
    SECRET,
    f"{client}|{nonce}|{idem}|{body}".encode(),
    hashlib.sha256
).hexdigest()

headers={
    "Content-Type":"application/json",
    "X-Lab-Key-Id":client,
    "X-Lab-Nonce":nonce,
    "Idempotency-Key":idem,
    "X-Lab-Signature":signature
}

barrier=threading.Barrier(2)
results=[]

def send_copy(index):
    barrier.wait()
    try:
        c=http.client.HTTPConnection(HOST,PORT,timeout=8)
        c.request("POST","/api/lab-transfer",body=body,headers=headers)
        r=c.getresponse()
        payload=r.read().decode()
        c.close()
        results.append((index,r.status,payload))
    except Exception as e:
        results.append((index,0,str(e)))

threads=[threading.Thread(target=send_copy,args=(i,)) for i in (1,2)]
for t in threads: t.start()
for t in threads: t.join()

results.sort()
for index,status,payload in results:
    print(f"copy={index} status={status} response={payload}")

statuses=[x[1] for x in results]
print("attacker_started=yes")
print("replay_sent=yes")

if 201 in statuses and 409 in statuses:
    print("secure_replay_rejected=yes")
else:
    print("secure_replay_rejected=no")
