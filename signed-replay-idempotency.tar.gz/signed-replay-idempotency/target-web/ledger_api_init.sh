#!/bin/sh
### BEGIN INIT INFO
# Provides:          ledger-api
# Required-Start:    $network
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Fintech Signed Ledger & Idempotency API Daemon
### END INIT INFO

DAEMON="/usr/local/bin/ledger_daemon.py"
PIDFILE="/var/run/ledger-api.pid"

case "$1" in
  start)
    echo "Starting ledger-api..."
    if [ -f "$PIDFILE" ] && kill -0 $(cat "$PIDFILE") 2>/dev/null; then
        echo "ledger-api is already running."
        exit 0
    fi
    nohup /usr/bin/python3 "$DAEMON" >/var/log/ledger-api/daemon.err 2>&1 &
    echo $! > "$PIDFILE"
    ;;
  stop)
    echo "Stopping ledger-api..."
    if [ -f "$PIDFILE" ]; then
        kill $(cat "$PIDFILE") 2>/dev/null
        rm -f "$PIDFILE"
    fi
    pkill -f ledger_daemon.py 2>/dev/null || true
    ;;
  restart)
    $0 stop
    sleep 1
    $0 start
    ;;
  status)
    if [ -f "$PIDFILE" ] && kill -0 $(cat "$PIDFILE") 2>/dev/null; then
        echo "ledger-api is running (PID $(cat $PIDFILE))"
    else
        echo "ledger-api is stopped"
        exit 1
    fi
    ;;
  *)
    echo "Usage: service ledger-api {start|stop|restart|status}"
    exit 1
    ;;
esac
exit 0
