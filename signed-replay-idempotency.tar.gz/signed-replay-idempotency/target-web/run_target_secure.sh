#!/bin/bash
set -e

TARGET_PIDS=$(
  ps -eo pid=,args= |
  awk '/[p]ython3 .*target_api\.py/ {print $1}'
)

if test -n "$TARGET_PIDS"; then
    kill -9 $TARGET_PIDS 2>/dev/null || true
fi

sleep 2

rm -f /home/ubuntu/target-api.pid /home/ubuntu/target-secure.log

nohup env TARGET_MODE=secure RESET_LEDGER=no \
  python3 /home/ubuntu/target_api.py \
  > /home/ubuntu/target-secure.log 2>&1 &

echo $! > /home/ubuntu/target-api.pid
sleep 1

if ! kill -0 "$(cat /home/ubuntu/target-api.pid)" 2>/dev/null; then
    echo "Khởi động target secure thất bại:"
    cat /home/ubuntu/target-secure.log
    exit 1
fi

echo "secure_target_started=yes"
echo "TARGET_MODE=secure"
echo "Target secure chạy nền."
