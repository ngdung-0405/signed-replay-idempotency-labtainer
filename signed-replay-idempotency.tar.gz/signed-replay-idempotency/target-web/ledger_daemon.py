#!/usr/bin/env python3
import os
import time
import json
import hmac
import hashlib
import sqlite3
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from datetime import datetime

CONF_PATH = "/etc/ledger-api/api.conf"
DB_DIR = "/var/lib/ledger-api"
DB_PATH = os.path.join(DB_DIR, "lab_ledger.db")
LOG_DIR = "/var/log/ledger-api"
AUDIT_LOG = os.path.join(LOG_DIR, "audit.log")

DB_WRITE_LOCK = threading.Lock()

def load_config():
    cfg = {
        "IDEMPOTENCY_MODE": "vulnerable_toctou",
        "HMAC_SHARED_SECRET": "LAB_ONLY_DEMO_HMAC_SECRET",
        "RACE_WINDOW_MS": "350"
    }
    if os.path.exists(CONF_PATH):
        with open(CONF_PATH, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    cfg[k.strip()] = v.strip()
    return cfg

def write_audit(entry):
    os.makedirs(LOG_DIR, exist_ok=True)
    with open(AUDIT_LOG, "a") as f:
        f.write(entry + "\n")

def init_db():
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10.0)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS ledger_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_id TEXT,
            nonce TEXT,
            idempotency_key TEXT,
            points INTEGER,
            note TEXT,
            mode TEXT,
            status TEXT,
            created_at TEXT
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS idempotency_guard (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_id TEXT NOT NULL,
            nonce TEXT NOT NULL,
            idempotency_key TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(client_id, nonce)
        )
    """)
    conn.commit()
    conn.close()

def compute_hmac(secret, client_id, nonce, idem_key, raw_body):
    msg = f"{client_id}|{nonce}|{idem_key}|{raw_body}".encode("utf-8")
    return hmac.new(secret.encode("utf-8"), msg, hashlib.sha256).hexdigest()

class LedgerAPIHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        cfg = load_config()
        mode = cfg.get("IDEMPOTENCY_MODE", "vulnerable_toctou")

        if self.path.startswith("/health"):
            body = json.dumps({
                "ready": True,
                "service": "ledger-api",
                "idempotency_mode": mode
            }, indent=2).encode("utf-8") + b"\n"
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if self.path.startswith("/api/ledger"):
            conn = sqlite3.connect(DB_PATH, timeout=10.0)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT * FROM ledger_transactions ORDER BY id ASC")
            rows = [dict(r) for r in cur.fetchall()]
            cur.execute("SELECT * FROM idempotency_guard ORDER BY id ASC")
            guards = [dict(r) for r in cur.fetchall()]
            conn.close()

            # Compute audit summary flags
            race_count = sum(1 for r in rows if r["nonce"] == "capture-race-001")
            sec_count = sum(1 for r in rows if r["nonce"] == "capture-secure-001")
            vic_count = sum(1 for r in rows if r["nonce"].startswith("victim-"))

            body = json.dumps({
                "idempotency_mode": mode,
                "summary": {
                    "victim_legitimate_transactions": vic_count,
                    "race_001_ledger_executions": race_count,
                    "double_execution_confirmed": (race_count >= 2),
                    "secure_001_ledger_executions": sec_count,
                    "single_execution_verified": (sec_count == 1),
                    "atomic_guard_entries": len(guards)
                },
                "ledger_transactions": rows,
                "idempotency_guard": guards
            }, indent=2).encode("utf-8") + b"\n"
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        body = b'{"status":"ledger-api online","endpoints":["/health","/api/ledger","/api/lab-transfer"]}\n'
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        cfg = load_config()
        mode = cfg.get("IDEMPOTENCY_MODE", "vulnerable_toctou")
        secret = cfg.get("HMAC_SHARED_SECRET", "LAB_ONLY_DEMO_HMAC_SECRET")
        race_ms = int(cfg.get("RACE_WINDOW_MS", "350"))
        ts = datetime.utcnow().strftime("%d/%b/%Y:%H:%M:%S +0000")

        if self.path != "/api/lab-transfer":
            self.send_response(404)
            self.end_headers()
            return

        length = int(self.headers.get("Content-Length", "0"))
        raw_body = self.rfile.read(length).decode("utf-8", errors="replace").strip()

        client_id = self.headers.get("X-Lab-Key-Id", "")
        nonce = self.headers.get("X-Lab-Nonce", "")
        idem_key = self.headers.get("Idempotency-Key", "")
        sig = self.headers.get("X-Lab-Signature", "")

        expected_sig = compute_hmac(secret, client_id, nonce, idem_key, raw_body)
        if not client_id or not nonce or not idem_key or not hmac.compare_digest(sig, expected_sig):
            write_audit(f"[{ts}] LEDGER_API status=401 action=HMAC_VERIFICATION_FAILED client={client_id} nonce={nonce}")
            body = json.dumps({"error": "401_INVALID_HMAC_SIGNATURE", "mode": mode}).encode("utf-8") + b"\n"
            self.send_response(401)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        try:
            payload = json.loads(raw_body)
        except Exception:
            payload = {}
        points = int(payload.get("points", 10))
        note = str(payload.get("note", ""))

        # ==============================================================
        # MODE 1: VULNERABLE TOCTOU (Non-atomic SELECT -> Sleep -> INSERT)
        # ==============================================================
        if mode == "vulnerable_toctou":
            conn = sqlite3.connect(DB_PATH, timeout=10.0)
            cur = conn.cursor()
            cur.execute(
                "SELECT COUNT(*) FROM ledger_transactions WHERE client_id=? AND (nonce=? OR idempotency_key=?)",
                (client_id, nonce, idem_key)
            )
            already_exists = cur.fetchone()[0] > 0
            conn.close()

            if already_exists:
                write_audit(f"[{ts}] LEDGER_API mode={mode} status=409 client={client_id} nonce={nonce} action=LATE_DUPLICATE_REJECTED")
                body = json.dumps({"error": "duplicate nonce or idempotency key", "mode": mode}).encode("utf-8") + b"\n"
                self.send_response(409)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            # TOCTOU Race Window (0.35s) where concurrent identical signed requests both passed SELECT!
            time.sleep(race_ms / 1000.0)

            with DB_WRITE_LOCK:
                conn = sqlite3.connect(DB_PATH, timeout=10.0)
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO ledger_transactions (client_id, nonce, idempotency_key, points, note, mode, status, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, 'success', ?)",
                    (client_id, nonce, idem_key, points, note, mode, ts)
                )
                tx_id = cur.lastrowid
                cur.execute("SELECT COUNT(*) FROM ledger_transactions WHERE nonce=?", (nonce,))
                nonce_count = cur.fetchone()[0]
                conn.commit()
                conn.close()

            if nonce.startswith("victim-"):
                write_audit(
                    f"[{ts}] LEDGER_API mode={mode} status=201 tx_id={tx_id} client={client_id} "
                    f"nonce={nonce} points={points} VICTIM_TRANSFER_RECORDED=YES"
                )
            elif nonce_count >= 2:
                write_audit(
                    f"[{ts}] LEDGER_API mode={mode} status=201 tx_id={tx_id} client={client_id} "
                    f"nonce={nonce} copies_in_ledger={nonce_count} DOUBLE_EXECUTION_CONFIRMED=YES LEDGER_DUPLICATE_SUCCESS=YES"
                )
            else:
                write_audit(
                    f"[{ts}] LEDGER_API mode={mode} status=201 tx_id={tx_id} client={client_id} "
                    f"nonce={nonce} copies_in_ledger={nonce_count}"
                )

            body = json.dumps({
                "result": "accepted",
                "tx_id": tx_id,
                "nonce": nonce,
                "copies_in_ledger": nonce_count,
                "mode": mode
            }).encode("utf-8") + b"\n"
            self.send_response(201)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        # ==============================================================
        # MODE 2: SECURE ATOMIC UNIQUE (Atomic INSERT into idempotency_guard)
        # ==============================================================
        with DB_WRITE_LOCK:
            conn = sqlite3.connect(DB_PATH, timeout=10.0)
            cur = conn.cursor()
            try:
                cur.execute(
                    "INSERT INTO idempotency_guard (client_id, nonce, idempotency_key, created_at) VALUES (?, ?, ?, ?)",
                    (client_id, nonce, idem_key, ts)
                )
                cur.execute(
                    "INSERT INTO ledger_transactions (client_id, nonce, idempotency_key, points, note, mode, status, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, 'success', ?)",
                    (client_id, nonce, idem_key, points, note, mode, ts)
                )
                tx_id = cur.lastrowid
                conn.commit()
                conn.close()
            except sqlite3.IntegrityError:
                conn.close()
                write_audit(
                    f"[{ts}] LEDGER_API mode={mode} status=409 client={client_id} nonce={nonce} "
                    f"action=UNIQUE_CONSTRAINT_BLOCKED SECURE_REPLAY_REJECTED=YES SINGLE_EXECUTION_VERIFIED=YES"
                )
                body = json.dumps({
                    "error": "409_ATOMIC_IDEMPOTENCY_CONFLICT",
                    "reason": "UNIQUE(client_id, nonce) constraint in idempotency_guard blocked duplicate execution",
                    "nonce": nonce,
                    "mode": mode
                }).encode("utf-8") + b"\n"
                self.send_response(409)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

        write_audit(
            f"[{ts}] LEDGER_API mode={mode} status=201 tx_id={tx_id} client={client_id} "
            f"nonce={nonce} SECURE_ATOMIC_INSERT=YES"
        )
        body = json.dumps({
            "result": "accepted",
            "tx_id": tx_id,
            "nonce": nonce,
            "atomic_guard": "INSERTED_UNIQUE",
            "mode": mode
        }).encode("utf-8") + b"\n"
        self.send_response(201)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

if __name__ == "__main__":
    init_db()
    os.makedirs(LOG_DIR, exist_ok=True)
    if not os.path.exists(AUDIT_LOG):
        open(AUDIT_LOG, "a").close()
    server = ThreadingHTTPServer(("0.0.0.0", 80), LedgerAPIHandler)
    server.serve_forever()
