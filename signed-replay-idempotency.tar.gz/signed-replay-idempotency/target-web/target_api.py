#!/usr/bin/env python3
import base64
import hashlib
import hmac
import json
import os
import sqlite3
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

MODE = os.environ.get("TARGET_MODE", "vulnerable")
DB = "/home/ubuntu/lab_ledger.db"
SECRET = b"LAB_ONLY_DEMO_HMAC_SECRET"

def connect():
    db = sqlite3.connect(DB, timeout=5, check_same_thread=False)
    db.row_factory = sqlite3.Row
    return db

def init_db(reset=False):
    if reset and os.path.exists(DB):
        os.remove(DB)

    db = connect()
    db.execute("""
        CREATE TABLE IF NOT EXISTS ledger (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_id TEXT NOT NULL,
            nonce TEXT NOT NULL,
            idem_key TEXT NOT NULL,
            points INTEGER NOT NULL,
            note TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at REAL NOT NULL
        )
    """)

    if MODE == "secure":
        db.execute("""
            CREATE TABLE IF NOT EXISTS idempotency_guard (
                client_id TEXT NOT NULL,
                nonce TEXT NOT NULL,
                idem_key TEXT NOT NULL,
                created_at REAL NOT NULL,
                UNIQUE(client_id, nonce),
                UNIQUE(client_id, idem_key)
            )
        """)

    db.commit()
    db.close()

def text_reply(handler, status, data):
    raw = data.encode()
    handler.send_response(status)
    handler.send_header("Content-Type", "text/plain")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)

def json_reply(handler, status, data):
    raw = json.dumps(data, ensure_ascii=False).encode()
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)

def canonical(client, nonce, idem, body):
    return f"{client}|{nonce}|{idem}|{body}".encode()

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print("[target] " + fmt % args, flush=True)

    def do_GET(self):
        parsed = urlsplit(self.path)

        if parsed.path == "/health":
            return json_reply(self, 200, {"ready": True, "mode": MODE})

        if parsed.path == "/api/lab-balance":
            db = connect()
            row = db.execute(
                "SELECT COALESCE(SUM(points),0) AS balance, COUNT(*) AS entries "
                "FROM ledger WHERE status='success'"
            ).fetchone()
            db.close()
            return json_reply(self, 200, dict(row))

        # Endpoint lab-only: mô phỏng attacker lấy được request hợp lệ đã ký.
        # Chỉ trả bản ghi và chữ ký, không trả HMAC secret.
        if parsed.path == "/api/lab-capture":
            label = parse_qs(parsed.query).get("label", ["race-001"])[0]

            if (not label or len(label) > 30 or
                    any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for c in label)):
                return json_reply(self, 400, {"error": "invalid capture label"})

            client = "student-a"
            nonce = "capture-" + label
            idem = "capture-transfer-" + label
            body = json.dumps(
                {
                    "from": client,
                    "to": "lab-store",
                    "points": 10,
                    "note": "CAPTURED_" + label
                },
                separators=(",", ":")
            )

            signature = hmac.new(
                SECRET,
                canonical(client, nonce, idem, body),
                hashlib.sha256
            ).hexdigest()

            # Dạng shell variables để attacker Base64 decode rồi tự kiểm tra.
            capture = (
                f"CLIENT={client}\n"
                f"NONCE={nonce}\n"
                f"IDEM={idem}\n"
                f"BODY='{body}'\n"
                f"SIGNATURE={signature}\n"
            )

            print(
                "[target] capture_created nonce_fp=" +
                hashlib.sha256(nonce.encode()).hexdigest()[:12],
                flush=True
            )

            return text_reply(
                self,
                200,
                base64.b64encode(capture.encode()).decode()
            )

        return json_reply(self, 404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/api/lab-transfer":
            return json_reply(self, 404, {"error": "not found"})

        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        body = raw.decode(errors="replace")

        client = self.headers.get("X-Lab-Key-Id", "")
        nonce = self.headers.get("X-Lab-Nonce", "")
        idem = self.headers.get("Idempotency-Key", "")
        signature = self.headers.get("X-Lab-Signature", "")

        try:
            payload = json.loads(body)
            points = int(payload["points"])
            note = str(payload["note"])
        except Exception:
            return json_reply(self, 400, {"error": "invalid lab payload"})

        if client != "student-a" or not nonce or not idem:
            return json_reply(self, 401, {"error": "invalid identity"})

        expected = hmac.new(
            SECRET,
            canonical(client, nonce, idem, body),
            hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(expected, signature):
            print("[target] signature_invalid", flush=True)
            return json_reply(self, 401, {"error": "signature rejected"})

        if MODE == "vulnerable":
            db = connect()
            duplicate = db.execute(
                "SELECT 1 FROM ledger WHERE client_id=? AND (nonce=? OR idem_key=?)",
                (client, nonce, idem)
            ).fetchone()
            db.close()

            if duplicate:
                return json_reply(self, 409, {"error": "duplicate request"})

            # Cố ý tạo race window cho hai replay request.
            time.sleep(0.35)

            db = connect()
            db.execute(
                "INSERT INTO ledger(client_id,nonce,idem_key,points,note,status,created_at) "
                "VALUES(?,?,?,?,?,?,?)",
                (client, nonce, idem, points, note, "success", time.time())
            )
            db.commit()
            db.close()

            print("[target] VULNERABLE_SUCCESS nonce_fp=" +
                  hashlib.sha256(nonce.encode()).hexdigest()[:12], flush=True)
            return json_reply(self, 201, {"result": "accepted", "mode": MODE})

        try:
            db = connect()
            db.execute(
                "INSERT INTO idempotency_guard(client_id,nonce,idem_key,created_at) "
                "VALUES(?,?,?,?)",
                (client, nonce, idem, time.time())
            )
            db.commit()
            db.close()
        except sqlite3.IntegrityError:
            print("[target] REPLAY_REJECTED nonce_fp=" +
                  hashlib.sha256(nonce.encode()).hexdigest()[:12], flush=True)
            return json_reply(
                self, 409,
                {"error": "duplicate nonce or idempotency key", "mode": MODE}
            )

        db = connect()
        db.execute(
            "INSERT INTO ledger(client_id,nonce,idem_key,points,note,status,created_at) "
            "VALUES(?,?,?,?,?,?,?)",
            (client, nonce, idem, points, note, "success", time.time())
        )
        db.commit()
        db.close()

        print("[target] SECURE_SUCCESS nonce_fp=" +
              hashlib.sha256(nonce.encode()).hexdigest()[:12], flush=True)
        return json_reply(self, 201, {"result": "accepted", "mode": MODE})

reset = os.environ.get("RESET_LEDGER", "no") == "yes"
init_db(reset)

print("target_started=yes", flush=True)
print("TARGET_MODE=" + MODE, flush=True)

ThreadingHTTPServer.allow_reuse_address = True
ThreadingHTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
