#!/bin/bash
set -e

TARGET_PIDS=$(
  ps -eo pid=,args= |
  awk '/[p]ython3 .*target_api\.py/ {print $1}'
)

if test -n "$TARGET_PIDS"; then
    kill -9 $TARGET_PIDS 2>/dev/null || true
fi

sleep 2

rm -f /home/ubuntu/target-api.pid /home/ubuntu/target-vulnerable.log

nohup env TARGET_MODE=vulnerable RESET_LEDGER=yes \
  python3 /home/ubuntu/target_api.py \
  > /home/ubuntu/target-vulnerable.log 2>&1 &

echo $! > /home/ubuntu/target-api.pid
sleep 1

if ! kill -0 "$(cat /home/ubuntu/target-api.pid)" 2>/dev/null; then
    echo "Khởi động target vulnerable thất bại:"
    cat /home/ubuntu/target-vulnerable.log
    exit 1
fi

echo "target_started=yes"
echo "TARGET_MODE=vulnerable"
echo "Target vulnerable chạy nền."
