#!/bin/bash
sudo mkdir -p /var/log/ledger-api /var/lib/ledger-api /etc/ledger-api
sudo touch /var/log/ledger-api/audit.log
sudo chmod -R 755 /var/log/ledger-api /var/lib/ledger-api
sudo cp /home/ubuntu/ledger_daemon.py /usr/local/bin/ledger_daemon.py
sudo chmod +x /usr/local/bin/ledger_daemon.py
sudo cp /home/ubuntu/ledger_api_init.sh /etc/init.d/ledger-api
sudo chmod +x /etc/init.d/ledger-api
sudo service ledger-api start || true

if ! grep -q "ledger_daemon.py" /home/ubuntu/.bashrc; then
cat << 'BRC' >> /home/ubuntu/.bashrc
if ! pgrep -f ledger_daemon.py >/dev/null 2>&1; then
    sudo service ledger-api start >/dev/null 2>&1 || true
fi
BRC
fi
