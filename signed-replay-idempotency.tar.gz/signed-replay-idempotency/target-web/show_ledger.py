#!/usr/bin/env python3
import sqlite3

DB = "/home/ubuntu/lab_ledger.db"
db = sqlite3.connect(DB)

print("=== LAB LEDGER ===")

rows = db.execute(
    "SELECT id, nonce, idem_key, points, note, status "
    "FROM ledger ORDER BY id"
).fetchall()

for row in rows:
    print(
        "id=%s nonce=%s idem=%s points=%s note=%s status=%s" % row
    )

victim_count = db.execute(
    "SELECT COUNT(*) FROM ledger "
    "WHERE nonce LIKE 'victim-%' AND status='success'"
).fetchone()[0]

duplicate_count = db.execute(
    "SELECT COUNT(*) FROM ("
    "  SELECT client_id, nonce "
    "  FROM ledger "
    "  WHERE status='success' "
    "  GROUP BY client_id, nonce "
    "  HAVING COUNT(*) > 1"
    ")"
).fetchone()[0]

secure_ledger_count = db.execute(
    "SELECT COUNT(*) FROM ledger "
    "WHERE nonce LIKE 'capture-secure-%' AND status='success'"
).fetchone()[0]

try:
    secure_guard_count = db.execute(
        "SELECT COUNT(*) FROM idempotency_guard "
        "WHERE nonce LIKE 'capture-secure-%'"
    ).fetchone()[0]
except sqlite3.OperationalError:
    secure_guard_count = 0

print("victim_transfer_recorded=" + ("yes" if victim_count >= 1 else "no"))
print("double_execution_confirmed=" + ("yes" if duplicate_count >= 1 else "no"))
print("secure_atomic_insert=" + ("yes" if secure_guard_count == 1 else "no"))
print("secure_replay_rejected=" + (
    "yes" if secure_guard_count == 1 and secure_ledger_count == 1 else "no"
))
print("single_execution_verified=" + (
    "yes" if secure_ledger_count == 1 else "no"
))

db.close()
