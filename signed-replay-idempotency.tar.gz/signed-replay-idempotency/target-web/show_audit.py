#!/usr/bin/env python3
import sqlite3

db = sqlite3.connect("/home/ubuntu/lab_ledger.db")

duplicates = db.execute(
    "SELECT COUNT(*) FROM ("
    "  SELECT client_id, nonce "
    "  FROM ledger "
    "  WHERE status='success' "
    "  GROUP BY client_id, nonce "
    "  HAVING COUNT(*) > 1"
    ")"
).fetchone()[0]

try:
    guard_count = db.execute(
        "SELECT COUNT(*) FROM idempotency_guard "
        "WHERE nonce LIKE 'capture-secure-%'"
    ).fetchone()[0]
except sqlite3.OperationalError:
    guard_count = 0

secure_count = db.execute(
    "SELECT COUNT(*) FROM ledger "
    "WHERE nonce LIKE 'capture-secure-%' AND status='success'"
).fetchone()[0]

print("=== ATOMIC IDEMPOTENCY AUDIT ===")
print("ledger_duplicate_success=" + ("yes" if duplicates >= 1 else "no"))
print("secure_atomic_insert=" + ("yes" if guard_count == 1 else "no"))
print("secure_replay_rejected=" + (
    "yes" if guard_count == 1 and secure_count == 1 else "no"
))
print("single_execution_verified=" + ("yes" if secure_count == 1 else "no"))

db.close()
