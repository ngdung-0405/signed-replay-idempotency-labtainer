#!/usr/bin/env python3
text=open("/home/ubuntu/replay.rules").read()
print("rule_created=" + ("yes" if "replay_nonce_fingerprint" in text else "no"))
