#!/usr/bin/env python3
import hashlib
import http.client
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

EVENTS="/home/ubuntu/gateway-events.log"
LOCK=threading.Lock()
seen={}

def event(text):
    line=time.strftime("%Y-%m-%dT%H:%M:%S")+" "+text
    print("[gateway] "+line, flush=True)
    with LOCK:
        with open(EVENTS, "a") as f:
            f.write(line+"\n")

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print("[gateway] "+fmt % args, flush=True)

    def do_GET(self):
        self.forward()

    def do_POST(self):
        nonce=self.headers.get("X-Lab-Nonce","")
        if nonce:
            fp=hashlib.sha256(nonce.encode()).hexdigest()[:12]
            now=time.time()
            with LOCK:
                seen.setdefault(fp, []).append(now)
                seen[fp]=[x for x in seen[fp] if now-x <= 2.0]
                count=len(seen[fp])
            event(f"REQUEST nonce_fp={fp} source={self.client_address[0]} count={count}")
            if count >= 2:
                event(f"REPLAY_CANDIDATE nonce_fp={fp} connections={count} window=2s")

        self.forward()

    def forward(self):
        length=int(self.headers.get("Content-Length","0"))
        body=self.rfile.read(length) if length else None

        headers={
            k:v for k,v in self.headers.items()
            if k.lower() not in ("host","connection","content-length")
        }
        if body is not None:
            headers["Content-Length"]=str(len(body))

        try:
            c=http.client.HTTPConnection("172.20.0.10",8080,timeout=5)
            c.request(self.command,self.path,body=body,headers=headers)
            r=c.getresponse()
            data=r.read()
            self.send_response(r.status)
            for k,v in r.getheaders():
                if k.lower() not in ("transfer-encoding","connection"):
                    self.send_header(k,v)
            self.end_headers()
            self.wfile.write(data)
            c.close()
        except Exception as e:
            raw=json.dumps({"error":"backend unavailable"}).encode()
            self.send_response(502)
            self.send_header("Content-Length",str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

print("gateway_started=yes", flush=True)
ThreadingHTTPServer(("0.0.0.0",8080),Handler).serve_forever()
