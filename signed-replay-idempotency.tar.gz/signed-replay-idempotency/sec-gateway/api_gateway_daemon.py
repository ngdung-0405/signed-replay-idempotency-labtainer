#!/usr/bin/env python3
import os
import time
import json
import hashlib
import threading
import urllib.request
import urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from datetime import datetime

RULE_PATH = "/etc/sec-gateway/replay.rules"
GATEWAY_LOG = "/var/log/sec-gateway/gateway-events.log"
SURICATA_LOG = "/var/log/suricata/fast.log"

NONCE_LOCK = threading.Lock()
NONCE_HISTORY = {}  # { nonce_fp: [timestamps...] }

def load_rules():
    cfg = {
        "REPLAY_THRESHOLD": "2",
        "REPLAY_WINDOW_SECONDS": "2",
        "UPSTREAM_HOST": "172.20.0.10",
        "UPSTREAM_PORT": "80"
    }
    if os.path.exists(RULE_PATH):
        with open(RULE_PATH, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    cfg[k.strip()] = v.strip()
    return cfg

def write_gateway_log(entry):
    os.makedirs(os.path.dirname(GATEWAY_LOG), exist_ok=True)
    with open(GATEWAY_LOG, "a") as f:
        f.write(entry + "\n")

def write_suricata_alert(src_ip, dst_ip, nonce_fp, count):
    os.makedirs(os.path.dirname(SURICATA_LOG), exist_ok=True)
    ts = datetime.utcnow().strftime("%m/%d/%Y-%H:%M:%S.%f")
    with open(SURICATA_LOG, "a") as f:
        f.write(
            f"{ts}  [**] [1:5000101:1] [SURICATA-GATEWAY] Signed HTTP Request Concurrent Replay Detected "
            f"(Duplicate X-Lab-Nonce Fingerprint within 2s Window) [**] [Classification: Web Application Attack] "
            f"[Priority: 1] {{TCP}} {src_ip}:53210 -> {dst_ip}:80 nonce_fp={nonce_fp} burst_count={count}\n"
        )

class APIGatewayHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        cfg = load_rules()
        host = cfg.get("UPSTREAM_HOST", "172.20.0.10")
        port = int(cfg.get("UPSTREAM_PORT", "80"))
        url = f"http://{host}:{port}{self.path}"
        req = urllib.request.Request(url, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=5) as resp:
                status, body = resp.status, resp.read()
        except urllib.error.HTTPError as e:
            status, body = e.code, e.read()

        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        cfg = load_rules()
        threshold = int(cfg.get("REPLAY_THRESHOLD", "2"))
        window_sec = float(cfg.get("REPLAY_WINDOW_SECONDS", "2"))
        host = cfg.get("UPSTREAM_HOST", "172.20.0.10")
        port = int(cfg.get("UPSTREAM_PORT", "80"))
        ts = datetime.utcnow().strftime("%d/%b/%Y:%H:%M:%S +0000")
        client_ip = self.client_address[0]

        length = int(self.headers.get("Content-Length", "0"))
        raw_body = self.rfile.read(length) if length > 0 else b""

        client_id = self.headers.get("X-Lab-Key-Id", "")
        nonce = self.headers.get("X-Lab-Nonce", "")
        idem_key = self.headers.get("Idempotency-Key", "")
        sig = self.headers.get("X-Lab-Signature", "")

        nonce_fp = hashlib.sha256(nonce.encode("utf-8")).hexdigest()[:12] if nonce else "none"
        now = time.time()

        with NONCE_LOCK:
            hist = [t for t in NONCE_HISTORY.get(nonce_fp, []) if (now - t) <= window_sec]
            hist.append(now)
            NONCE_HISTORY[nonce_fp] = hist
            seen_count = len(hist)

        if seen_count >= threshold:
            write_gateway_log(
                f"[{ts}] SEC_GATEWAY event=REPLAY_CANDIDATE client={client_ip} key_id={client_id} "
                f"nonce_fp={nonce_fp} seen_in_window={seen_count} GATEWAY_REPLAY_DETECTED=YES"
            )
            write_suricata_alert(client_ip, "192.168.10.2", nonce_fp, seen_count)
        else:
            write_gateway_log(
                f"[{ts}] SEC_GATEWAY event=SIGNED_REQUEST_FORWARD client={client_ip} key_id={client_id} "
                f"nonce_fp={nonce_fp} seen_in_window={seen_count}"
            )

        url = f"http://{host}:{port}{self.path}"
        fwd_headers = {
            "Content-Type": "application/json",
            "X-Lab-Key-Id": client_id,
            "X-Lab-Nonce": nonce,
            "Idempotency-Key": idem_key,
            "X-Lab-Signature": sig
        }
        req = urllib.request.Request(url, data=raw_body, headers=fwd_headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                status, resp_body = resp.status, resp.read()
        except urllib.error.HTTPError as e:
            status, resp_body = e.code, e.read()

        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("X-Nonce-Fingerprint", nonce_fp)
        self.send_header("Content-Length", str(len(resp_body)))
        self.end_headers()
        self.wfile.write(resp_body)

if __name__ == "__main__":
    os.makedirs(os.path.dirname(GATEWAY_LOG), exist_ok=True)
    os.makedirs(os.path.dirname(SURICATA_LOG), exist_ok=True)
    for p in (GATEWAY_LOG, SURICATA_LOG):
        if not os.path.exists(p):
            open(p, "a").close()
    server = ThreadingHTTPServer(("0.0.0.0", 80), APIGatewayHandler)
    server.serve_forever()
