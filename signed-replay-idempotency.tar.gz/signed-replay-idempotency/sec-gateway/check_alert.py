#!/usr/bin/env python3
import os
p="/home/ubuntu/gateway-events.log"
text=open(p).read() if os.path.exists(p) else ""
print("gateway_replay_detected=" + ("yes" if "REPLAY_CANDIDATE" in text else "no"))
