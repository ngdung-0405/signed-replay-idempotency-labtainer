#!/bin/bash
sudo mkdir -p /var/log/sec-gateway /var/log/suricata /etc/sec-gateway /etc/suricata/rules
sudo touch /var/log/sec-gateway/gateway-events.log /var/log/suricata/fast.log
sudo chmod -R 755 /var/log/sec-gateway /var/log/suricata
sudo cp /home/ubuntu/api_gateway_daemon.py /usr/local/bin/api_gateway_daemon.py
sudo chmod +x /usr/local/bin/api_gateway_daemon.py
sudo cp /home/ubuntu/api_gateway_init.sh /etc/init.d/api-gateway
sudo chmod +x /etc/init.d/api-gateway
sudo service api-gateway start || true

if ! grep -q "api_gateway_daemon.py" /home/ubuntu/.bashrc; then
cat << 'BRC' >> /home/ubuntu/.bashrc
if ! pgrep -f api_gateway_daemon.py >/dev/null 2>&1; then
    sudo service api-gateway start >/dev/null 2>&1 || true
fi
BRC
fi
