#!/bin/bash
set -e

for i in $(seq 1 15); do
    nc -z 172.20.0.10 8080 2>/dev/null && break

    if test "$i" = 15; then
        echo "target_web_ready=no"
        echo "Hãy chạy ./run_target.sh trên target-web trước."
        exit 1
    fi

    sleep 1
done

PIDFILE=/home/ubuntu/gateway.pid

if test -f "$PIDFILE" && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    kill "$(cat "$PIDFILE")" 2>/dev/null || true
    sleep 1
fi

rm -f "$PIDFILE" /home/ubuntu/gateway-events.log /home/ubuntu/gateway.log

nohup python3 /home/ubuntu/gateway.py \
  > /home/ubuntu/gateway.log 2>&1 &

echo $! > "$PIDFILE"

sleep 1

if ! kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    cat /home/ubuntu/gateway.log
    exit 1
fi

echo "gateway_started=yes"
echo "Gateway đang chạy nền. Log: ~/gateway.log"
