#!/bin/bash
set -e

CLIENT=student-a
NONCE="victim-$(date +%s)"
IDEM="victim-transfer-$(date +%s)"
SECRET=LAB_ONLY_DEMO_HMAC_SECRET
BODY=$(cat ~/victim_payload.json)

CANONICAL="$CLIENT|$NONCE|$IDEM|$BODY"

SIGNATURE=$(
  printf '%s' "$CANONICAL" |
  openssl dgst -sha256 -hmac "$SECRET" -hex |
  awk '{print $NF}'
)

cat > ~/victim_request.env <<EOF
CLIENT=$CLIENT
NONCE=$NONCE
IDEM=$IDEM
BODY='$BODY'
SIGNATURE=$SIGNATURE
EOF

echo "HMAC SHA-256 đã tạo; không in secret."
echo "signature_created=yes"
