#!/bin/bash
sudo cp /home/ubuntu/sign_tx.py /usr/local/bin/sign_tx
sudo chmod +x /usr/local/bin/sign_tx /home/ubuntu/sign_tx.py
