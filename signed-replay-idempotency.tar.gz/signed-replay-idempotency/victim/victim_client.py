#!/usr/bin/env python3
import hashlib
import hmac
import http.client
import json

HOST="172.20.0.10"
PORT=8080
SECRET=b"LAB_ONLY_DEMO_HMAC_SECRET"

print("=== VICTIM: TẠO GIAO DỊCH ĐIỂM HỌC TẬP GIẢ LẬP ===")
note=input("Nhập ghi chú giao dịch: ").strip()
points_text=input("Nhập số điểm (1-50): ").strip()

try:
    points=int(points_text)
except ValueError:
    raise SystemExit("Điểm không hợp lệ.")

if not note or len(note)>100 or points < 1 or points > 50:
    raise SystemExit("Ghi chú hoặc số điểm không hợp lệ.")

client="student-a"
nonce="victim-lab-001"
idem="victim-transfer-001"
body=json.dumps(
    {"from":client,"to":"lab-store","points":points,"note":note},
    separators=(",",":")
)
canonical=f"{client}|{nonce}|{idem}|{body}".encode()
signature=hmac.new(SECRET,canonical,hashlib.sha256).hexdigest()

headers={
    "Content-Type":"application/json",
    "X-Lab-Key-Id":client,
    "X-Lab-Nonce":nonce,
    "Idempotency-Key":idem,
    "X-Lab-Signature":signature
}

c=http.client.HTTPConnection(HOST,PORT,timeout=5)
c.request("POST","/api/lab-transfer",body=body,headers=headers)
r=c.getresponse()
data=r.read().decode()
c.close()

print("HTTP status:",r.status)
print("Response:",data)
if r.status == 201:
    print("victim_transfer_created=yes")
