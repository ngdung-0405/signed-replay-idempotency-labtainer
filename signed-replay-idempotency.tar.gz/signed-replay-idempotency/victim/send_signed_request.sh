#!/bin/bash
set -e
source ~/victim_request.env

RESPONSE=$(
  curl -sS -i -X POST http://172.20.0.10:8080/api/lab-transfer \
    -H 'Content-Type: application/json' \
    -H "X-Lab-Key-Id: $CLIENT" \
    -H "X-Lab-Nonce: $NONCE" \
    -H "Idempotency-Key: $IDEM" \
    -H "X-Lab-Signature: $SIGNATURE" \
    --data "$BODY"
)

printf '%s\n' "$RESPONSE"

if printf '%s' "$RESPONSE" | grep -q '201 Created'; then
    echo "victim_transfer_created=yes"
else
    echo "victim_transfer_created=no"
    exit 1
fi
