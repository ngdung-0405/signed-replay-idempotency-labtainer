#!/bin/bash
set -e
echo "=== Base64 payload ==="
cat ~/victim_payload.b64
echo
echo "=== Decode Base64 ==="
base64 -d ~/victim_payload.b64
echo
echo "payload_decoded=yes"
