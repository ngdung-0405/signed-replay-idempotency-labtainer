#!/usr/bin/env python3
import time
import json
import hmac
import base64
import hashlib
import argparse
import urllib.request
import urllib.error

SECRET = "LAB_ONLY_DEMO_HMAC_SECRET"

def main():
    parser = argparse.ArgumentParser(description="Victim Signed Transaction Generator (Base64 + HMAC-SHA256)")
    parser.add_argument("--gateway", default="192.168.10.2", help="Gateway IP")
    parser.add_argument("--client", default="student-a", help="Client Key ID")
    parser.add_argument("--points", type=int, default=10, help="Points to transfer")
    parser.add_argument("--note", default="mua_tai_lieu_an_toan_web", help="Transaction note")
    args = parser.parse_args()

    ts = int(time.time())
    nonce = f"victim-{ts}"
    idem_key = f"victim-transfer-{ts}"

    payload_obj = {
        "from": args.client,
        "to": "lab-store",
        "points": args.points,
        "note": args.note
    }
    raw_json = json.dumps(payload_obj, separators=(",", ":"))
    b64_encoded = base64.b64encode(raw_json.encode("utf-8")).decode("utf-8")
    b64_decoded = base64.b64decode(b64_encoded.encode("utf-8")).decode("utf-8")

    canonical = f"{args.client}|{nonce}|{idem_key}|{b64_decoded}"
    signature = hmac.new(SECRET.encode("utf-8"), canonical.encode("utf-8"), hashlib.sha256).hexdigest()

    print("=== [1] JSON PAYLOAD & BASE64 ENCODE/DECODE VERIFICATION ===")
    print(f"Base64 Encoded : {b64_encoded}")
    print(f"Base64 Decoded : {b64_decoded}")
    print("\n=== [2] HMAC-SHA256 REQUEST SIGNING ===")
    print(f"X-Lab-Key-Id   : {args.client}")
    print(f"X-Lab-Nonce    : {nonce}")
    print(f"Idempotency-Key: {idem_key}")
    print(f"X-Lab-Signature: {signature}")

    url = f"http://{args.gateway}/api/lab-transfer"
    headers = {
        "Content-Type": "application/json",
        "X-Lab-Key-Id": args.client,
        "X-Lab-Nonce": nonce,
        "Idempotency-Key": idem_key,
        "X-Lab-Signature": signature
    }
    req = urllib.request.Request(url, data=b64_decoded.encode("utf-8"), headers=headers, method="POST")
    print(f"\n=== [3] SENDING SIGNED POST TO http://{args.gateway}/api/lab-transfer ===")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            print(f"HTTP/1.0 {resp.status} Created")
            print(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        print(f"HTTP/1.0 {e.code}")
        print(e.read().decode("utf-8"))

if __name__ == "__main__":
    main()
