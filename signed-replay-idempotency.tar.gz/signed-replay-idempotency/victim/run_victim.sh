#!/bin/bash
set -e

echo "=== VICTIM: TẠO, MÃ HÓA BASE64, KÝ HMAC VÀ GỬI REQUEST ==="

read -rp "Nhập ghi chú giao dịch: " NOTE
read -rp "Nhập số điểm (1-50): " POINTS

case "$POINTS" in
  ''|*[!0-9]*) echo "Điểm phải là số."; exit 1 ;;
esac

if test "$POINTS" -lt 1 || test "$POINTS" -gt 50; then
    echo "Điểm chỉ được từ 1 đến 50."
    exit 1
fi

NOTE=$(printf '%s' "$NOTE" | tr -cd '[:alnum:] .,_-')
test -n "$NOTE" || NOTE=victim_lab_transfer

CLIENT=student-a
NONCE="victim-$(date +%s)"
IDEM="victim-transfer-$(date +%s)"
SECRET=LAB_ONLY_DEMO_HMAC_SECRET

BODY=$(printf '{"from":"%s","to":"lab-store","points":%s,"note":"%s"}' \
  "$CLIENT" "$POINTS" "$NOTE")

printf '%s' "$BODY" > ~/victim_payload.json
base64 -w 0 ~/victim_payload.json > ~/victim_payload.b64

echo "=== Base64 payload ==="
cat ~/victim_payload.b64
echo
echo "=== Decode Base64 ==="
base64 -d ~/victim_payload.b64
echo
echo "payload_created=yes"
echo "payload_decoded=yes"

CANONICAL="$CLIENT|$NONCE|$IDEM|$BODY"

SIGNATURE=$(
  printf '%s' "$CANONICAL" |
  openssl dgst -sha256 -hmac "$SECRET" -hex |
  awk '{print $NF}'
)

echo "signature_created=yes"
echo "Đang gửi request đã ký tới target-web..."

RESPONSE=$(
  curl -sS -i --connect-timeout 5 --max-time 10 \
    -X POST http://192.168.10.2:8080/api/lab-transfer \
    -H 'Content-Type: application/json' \
    -H "X-Lab-Key-Id: $CLIENT" \
    -H "X-Lab-Nonce: $NONCE" \
    -H "Idempotency-Key: $IDEM" \
    -H "X-Lab-Signature: $SIGNATURE" \
    --data "$BODY"
)

printf '%s\n' "$RESPONSE"

if printf '%s\n' "$RESPONSE" | grep -q '201 Created'; then
    echo "victim_transfer_created=yes"
else
    echo "victim_transfer_created=no"
    exit 1
fi
