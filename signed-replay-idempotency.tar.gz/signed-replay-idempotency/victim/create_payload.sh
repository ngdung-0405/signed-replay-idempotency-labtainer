#!/bin/bash
set -e

read -rp "Nhập ghi chú giao dịch: " NOTE
read -rp "Nhập số điểm (1-50): " POINTS

case "$POINTS" in ''|*[!0-9]*) exit 1;; esac
test "$POINTS" -ge 1 && test "$POINTS" -le 50 || exit 1

NOTE=$(printf '%s' "$NOTE" | tr -cd '[:alnum:] .,_-')
test -n "$NOTE" || NOTE=victim_lab_transfer

printf '{"from":"student-a","to":"lab-store","points":%s,"note":"%s"}' \
  "$POINTS" "$NOTE" > ~/victim_payload.json

base64 -w 0 ~/victim_payload.json > ~/victim_payload.b64

echo "payload_created=yes"
echo "JSON: ~/victim_payload.json"
echo "Base64: ~/victim_payload.b64"
